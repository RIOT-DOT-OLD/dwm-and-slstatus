# slstatus
suckless status monitor
